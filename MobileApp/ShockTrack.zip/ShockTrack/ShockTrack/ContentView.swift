//
//  ContentView.swift
//  ShockTrack
//
//  Created by Nicholas Sullivan on 2025-10-30.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct RecordingCard: View {
    let title: String
    let time: String
    let date: String

    var body: some View {
        VStack(alignment: .leading) {
            Text(title).font(.headline)
            Text("\(date) • \(time)").font(.subheadline)
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
    }
}

struct CommunityPreview: View {
    var body: some View {
        HStack {
            Image("community_car")
                .resizable()
                .frame(width: 100, height: 80)
                .cornerRadius(8)
            VStack(alignment: .leading) {
                Text("DIY Shock Setup").font(.headline)
                Text("Tips from the community").font(.subheadline)
            }
        }
    }
}


#Preview {
    ContentView()
}
