//
//  CommunityView.swift
//  ShockTrack
//
//  Created by Nicholas Sullivan on 2025-10-30.
//

import SwiftUI

struct CommunityView: View {
    let posts = [
        ("DIY Shock Setup", "shock_image"),
        ("Track Day Highlights", "track_image")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                Text("Community").font(.largeTitle).bold()

                ForEach(posts, id: \.0) { post in
                    VStack(alignment: .leading) {
                        Image(post.1)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .clipped()
                        Text(post.0).font(.headline)
                    }
                    .padding(.bottom)
                }
            }
            .padding()
        }
    }
}
